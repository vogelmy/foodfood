const express = require('express');
const router = express.Router();
const {prodsModel,validProds} = require("../models/prods_model");

/* GET home page. */
router.get('/', (req, res, next) => {
  //req.params, req.query , req.body
  prodsModel.find()
  .then(data => {
    res.json(data);

  })
});

module.exports = router;
